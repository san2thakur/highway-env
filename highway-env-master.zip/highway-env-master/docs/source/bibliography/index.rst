.. _bibliography:

Bibliography
############

.. bibliography:: biblio.bib
	:encoding: latin
	:style: alpha
	:all:

.. Fix to make sure bibliography appear when bibliography called in separate file
.. latex+latin => latin
.. :cited: => :all: see http://sphinxcontrib-bibtex.readthedocs.io/en/latest/usage.html#unresolved-citations-across-documents

.. :style: alpha, plain , unsrt, and unsrtalpha